package com.ims.jpgtosketsa

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * "Ikuti Master": menyamakan tone dan kekuatan tekstur hasil sketsa dengan sketsa master
 * (mis. hasil Canva). Semua dihitung di HP, tanpa internet.
 *
 * Alur: analyze(master, maskMaster) -> Profile (simpan, kecil) ->
 *       apply(sketsa, maskSketsa, profile) -> Bitmap baru.
 * Mask boleh null (seluruh gambar dipakai), tapi hasil lebih akurat dengan mask objek
 * dari BackgroundRemover.detect() agar latar tidak ikut mempengaruhi histogram.
 */
object StyleMatch {
    private const val LO = 38      // batas hitam (pensil, bukan hitam murni)
    private const val HI = 252     // batas putih

    /** Profil gaya: histogram kecerahan objek master + kekuatan tekstur goresannya. */
    class Profile(val hist: IntArray, val total: Int, val texStd: Float)

    fun analyze(master: Bitmap, mask: BackgroundRemover.Mask?): Profile {
        val w = master.width
        val h = master.height
        val g = gray(master)
        val hist = IntArray(256)
        var n = 0
        for (y in 0 until h) for (x in 0 until w) {
            if (inside(mask, x, y, w, h)) { hist[g[y * w + x]]++; n++ }
        }
        val tex = texStd(g, w, h, mask)
        return Profile(hist, max(1, n), tex)
    }

    fun apply(sketch: Bitmap, mask: BackgroundRemover.Mask?, prof: Profile, texAmount: Float = 1f): Bitmap {
        val w = sketch.width
        val h = sketch.height
        val px = IntArray(w * h)
        sketch.getPixels(px, 0, w, 0, 0, w, h)
        val g = IntArray(w * h) {
            val c = px[it]
            (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000
        }
        // 1) Histogram matching: kecerahan objek sketsa -> distribusi master
        val sh = IntArray(256)
        var sn = 0
        for (y in 0 until h) for (x in 0 until w) if (inside(mask, x, y, w, h)) { sh[g[y * w + x]]++; sn++ }
        sn = max(1, sn)
        val lut = FloatArray(256)
        var sc = 0
        var mc = 0
        var mi = 0
        for (v in 0..255) {
            sc += sh[v]
            val target = sc.toFloat() / sn * prof.total
            while (mi < 255 && mc + prof.hist[mi] < target) { mc += prof.hist[mi]; mi++ }
            lut[v] = mi.toFloat()
        }
        // haluskan LUT supaya tidak ada pita (banding)
        val sl = FloatArray(256)
        for (v in 0..255) {
            var s = 0f
            var c = 0
            for (d in -3..3) { s += lut[(v + d).coerceIn(0, 255)]; c++ }
            sl[v] = s / c
        }
        val m = FloatArray(w * h) { sl[g[it]] }

        // 2) Kekuatan tekstur: band-pass halus dikali gain agar std tekstur = master
        val low = blurF(m, w, h, 1)
        val mid = blurF(m, w, h, 5)
        val band = FloatArray(w * h) { low[it] - mid[it] }
        val cur = texStdF(m, w, h, mask)
        val gain = ((prof.texStd / max(1e-3f, cur)) - 1f).coerceIn(0f, 1.2f) * texAmount

        val out = IntArray(w * h)
        for (i in 0 until w * h) {
            val a = px[i] ushr 24
            val inObj = inside(mask, i % w, i / w, w, h)
            val v = if (inObj) (m[i] + gain * band[i]).coerceIn(LO.toFloat(), HI.toFloat()) else 255f
            val k = v.roundToInt().coerceIn(0, 255)
            out[i] = Color.argb(a, k, k, k)
        }
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bmp.setPixels(out, 0, w, 0, 0, w, h)
        return bmp
    }

    // ---- util ----
    private fun gray(b: Bitmap): IntArray {
        val w = b.width
        val h = b.height
        val px = IntArray(w * h)
        b.getPixels(px, 0, w, 0, 0, w, h)
        return IntArray(w * h) {
            val c = px[it]
            ((Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000).coerceIn(0, 255)
        }
    }

    private fun inside(m: BackgroundRemover.Mask?, x: Int, y: Int, w: Int, h: Int): Boolean {
        if (m == null) return true
        val mx = min(m.w - 1, x * m.w / w)
        val my = min(m.h - 1, y * m.h / h)
        return m.a[my * m.w + mx] > 0.5f
    }

    private fun texStd(g: IntArray, w: Int, h: Int, mask: BackgroundRemover.Mask?): Float =
        texStdF(FloatArray(g.size) { g[it].toFloat() }, w, h, mask)

    /** Simpangan baku (nilai - blur lebar) di dalam objek = kekuatan tekstur goresan. */
    private fun texStdF(f: FloatArray, w: Int, h: Int, mask: BackgroundRemover.Mask?): Float {
        val r = max(2, (max(w, h) / 100f).roundToInt())
        val bl = blurF(f, w, h, r)
        var s = 0.0
        var q = 0.0
        var n = 0
        for (y in 0 until h) for (x in 0 until w) {
            if (!inside(mask, x, y, w, h)) continue
            val d = f[y * w + x] - bl[y * w + x]
            s += d; q += d * d; n++
        }
        if (n == 0) return 1f
        val mean = s / n
        return sqrt(max(1e-6, q / n - mean * mean)).toFloat()
    }

    /** Box blur terpisah (horizontal lalu vertikal), radius r. */
    private fun blurF(a: FloatArray, w: Int, h: Int, r: Int): FloatArray {
        val t = FloatArray(w * h)
        val o = FloatArray(w * h)
        val k = (2 * r + 1).toFloat()
        for (y in 0 until h) {
            val row = y * w
            var sum = 0f
            for (i in -r..r) sum += a[row + i.coerceIn(0, w - 1)]
            for (x in 0 until w) {
                t[row + x] = sum / k
                sum += a[row + min(x + r + 1, w - 1)] - a[row + max(x - r, 0)]
            }
        }
        for (x in 0 until w) {
            var sum = 0f
            for (i in -r..r) sum += t[i.coerceIn(0, h - 1) * w + x]
            for (y in 0 until h) {
                o[y * w + x] = sum / k
                sum += t[min(y + r + 1, h - 1) * w + x] - t[max(y - r, 0) * w + x]
            }
        }
        return o
    }
}
