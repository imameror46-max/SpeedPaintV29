package com.ims.jpgtosketsa

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.*
import java.io.File
import kotlin.math.max

class MainActivity : Activity() {
    private val cInk = 0xFF111111.toInt()
    private val cYellow = 0xFFFFC107.toInt()
    private val cBg = 0xFFFFF8E7.toInt()
    private val cField = 0xFFF4EFE0.toInt()
    private val cMuted = 0xFF6B6558.toInt()
    private val cDanger = 0xFFE5484D.toInt()

    // Status bersama
    private var srcUri: Uri? = null
    private var base: Bitmap? = null
    private var result: Bitmap? = null
    private var savedUri: Uri? = null
    private var savedPng = false
    private var videoUri: Uri? = null
    private var gen = 0
    private var tab = 0
    private var mode = 4
    private var autoMode = true
    private val manualVals = intArrayOf(40, 70, 75, 55)
    @Volatile private var cancelFlag = false
    private val handler = Handler(Looper.getMainLooper())
    private val job = Runnable { renderPreview() }

    // Status Hapus Latar
    private var cutMask: BackgroundRemover.Mask? = null
    private var cutResult: Bitmap? = null
    private var cutShow: Bitmap? = null
    private var cutSavedUri: Uri? = null
    private var cutBusy = false
    private var cutGen = 0
    private var photoGen = 0
    private val cutJob = Runnable { applyCut() }

    // Umum
    private lateinit var preview: ImageView
    private lateinit var hint: TextView
    private lateinit var tabBtns: List<Button>
    private lateinit var pageSketch: LinearLayout
    private lateinit var pageCut: LinearLayout
    private lateinit var pagePaint: LinearLayout

    // Tab Sketsa
    private lateinit var chips: List<Button>
    private lateinit var colorBox: LinearLayout
    private lateinit var autoBtns: List<Button>
    private lateinit var skBlur: SeekBar
    private lateinit var skDark: SeekBar
    private lateinit var skColor: SeekBar
    private lateinit var skGrain: SeekBar
    private lateinit var skPaper: Spinner
    private lateinit var skSave: Button
    private lateinit var skShare: Button
    private lateinit var skToVideo: Button
    private lateinit var skToCut: Button
    private lateinit var skStatus: TextView

    // Tab Hapus Latar
    private lateinit var cutRun: Button
    private lateinit var cutMethod: Spinner
    private lateinit var cutInk: Spinner
    private lateinit var cutThr: SeekBar
    private lateinit var cutSoft: SeekBar
    private lateinit var cutSave: Button
    private lateinit var cutShare: Button
    private lateinit var cutNext: Button
    private lateinit var cutStatus: TextView

    // Tab SpeedPaint
    private lateinit var spSrc: Spinner
    private lateinit var spStyle: Spinner
    private lateinit var spDir: Spinner
    private lateinit var spPaper: Spinner
    private lateinit var spInk: Spinner
    private lateinit var spRatio: Spinner
    private lateinit var spRes: Spinner
    private lateinit var spFps: Spinner
    private lateinit var spHold: Spinner
    private lateinit var spSource: Spinner
    private lateinit var spSens: Spinner
    private lateinit var spThick: Spinner
    private lateinit var seekDur: SeekBar
    private lateinit var seekHand: SeekBar
    private lateinit var seekSpeed: SeekBar
    private lateinit var handCheck: CheckBox
    private lateinit var handInfo: TextView
    private lateinit var generate: Button
    private lateinit var cancel: Button
    private lateinit var bar: ProgressBar
    private lateinit var pStatus: TextView
    private lateinit var watch: Button
    private lateinit var shareVideo: Button

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, r: Int, stroke: Int = 0) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat()
        if (stroke != 0) setStroke(dp(2), stroke)
    }

    private fun lp(top: Int = 0, h: Int = -2) = LinearLayout.LayoutParams(-1, h).apply { topMargin = dp(top) }

    private fun card(parent: LinearLayout, title: String): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.WHITE, 18, cInk)
            setPadding(dp(16), dp(14), dp(16), dp(16))
        }
        c.addView(TextView(this).apply { text = title; textSize = 16f; setTypeface(typeface, Typeface.BOLD); setTextColor(cInk) })
        parent.addView(c, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(14), dp(12), dp(14), 0) })
        return c
    }

    private fun button(text: String, bg: Int, fg: Int = cInk) = Button(this).apply {
        this.text = text; isAllCaps = false; textSize = 15f; setTextColor(fg)
        setTypeface(typeface, Typeface.BOLD)
        background = rounded(bg, 14, cInk); stateListAnimator = null
    }

    private fun spinner(p: LinearLayout, label: String, items: List<String>, sel: Int = 0): Spinner {
        p.addView(TextView(this).apply { text = label; textSize = 12f; setTextColor(cMuted); setPadding(dp(2), dp(10), 0, dp(4)) })
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        sp.setSelection(sel)
        val box = FrameLayout(this).apply { background = rounded(cField, 12); setPadding(dp(6), 0, dp(6), 0) }
        box.addView(sp, FrameLayout.LayoutParams(-1, dp(46)))
        p.addView(box)
        return sp
    }

    private fun seekRow(p: LinearLayout, label: (Int) -> String, mx: Int, init: Int, live: Boolean = false, onLive: (() -> Unit)? = null): Pair<LinearLayout, SeekBar> {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val tv = TextView(this).apply { text = label(init); textSize = 13f; setTextColor(cInk); setPadding(dp(2), dp(12), 0, 0) }
        val sb = SeekBar(this).apply {
            max = mx; progress = init
            progressTintList = ColorStateList.valueOf(cInk)
            thumbTintList = ColorStateList.valueOf(cYellow)
        }
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { tv.text = label(v); if (live) schedule(); onLive?.invoke() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(tv); box.addView(sb)
        p.addView(box)
        return Pair(box, sb)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        AiPortrait.init(this)
        SuperRes.init(this)
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = cBg
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, dp(28)) }

        // Header logo
        val header = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(8), dp(12), dp(14))
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                val r = dp(26).toFloat()
                cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
            }
            elevation = dp(4).toFloat()
        }
        header.addView(ImageView(this).apply {
            setImageResource(resources.getIdentifier("logo_header", "drawable", packageName))
            adjustViewBounds = true
        }, LinearLayout.LayoutParams(-1, dp(150)))
        col.addView(header)
        col.addView(TextView(this).apply {
            text = "Versi 4.5 \u2022 Sketsa \u2192 Hapus Latar \u2192 SpeedPaint"; textSize = 11f; setTextColor(cMuted); gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
        })

        // Tab
        val tabRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tabBtns = listOf(button("1. Sketsa", Color.WHITE), button("2. Hapus Latar", Color.WHITE), button("3. SpeedPaint", Color.WHITE))
            .onEach { it.textSize = 13f; it.maxLines = 1; it.setPadding(dp(2), 0, dp(2), 0) }
        tabBtns.forEachIndexed { i, t ->
            tabRow.addView(t, LinearLayout.LayoutParams(0, dp(50), 1f).apply { if (i > 0) leftMargin = dp(6) })
            t.setOnClickListener { selectTab(i) }
        }
        col.addView(tabRow, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(14), dp(14), dp(14), 0) })

        // Foto (bersama)
        val c1 = card(col, "Foto")
        val pick = button("Pilih Foto dari Galeri", cYellow)
        c1.addView(pick, lp(10, dp(50)))
        preview = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        hint = TextView(this).apply { text = "Belum ada foto"; setTextColor(cMuted); gravity = Gravity.CENTER }
        val pbox = FrameLayout(this).apply { background = rounded(cField, 14); setPadding(dp(6), dp(6), dp(6), dp(6)) }
        pbox.addView(hint, FrameLayout.LayoutParams(-1, -1))
        pbox.addView(preview, FrameLayout.LayoutParams(-1, -1))
        c1.addView(pbox, lp(12, dp(320)))
        c1.addView(TextView(this).apply { text = "Di tab Sketsa dan Hapus Latar, tahan gambar untuk melihat foto asli"; textSize = 12f; setTextColor(cMuted); setPadding(dp(2), dp(8), 0, 0) })

        pageSketch = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        pageCut = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        pagePaint = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(pageSketch); col.addView(pageCut); col.addView(pagePaint)
        buildSketchPage()
        buildCutPage()
        buildPaintPage()

        setContentView(ScrollView(this).apply { setBackgroundColor(cBg); addView(col) })
        selectMode(1)
        selectAuto(true)
        selectTab(0)
        refreshHandInfo()

        preview.setOnTouchListener { _, e ->
            if (tab == 0 || tab == 1) when (e.action) {
                MotionEvent.ACTION_DOWN -> base?.let { preview.setImageBitmap(it) }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> updatePreview()
            }
            true
        }
        pick.setOnClickListener { startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }, 1) }
    }

    // ---------------- Tab Sketsa ----------------
    private fun buildSketchPage() {
        val c2 = card(pageSketch, "Gaya sketsa")
        val names = listOf("\uD83D\uDD8B\uFE0F Arsir", "\uD83E\uDD16 Arsir + AI", "\uD83C\uDFA8 Arsir Berwarna + AI")
        chips = names.map { button(it, Color.WHITE).apply { textSize = 12f; setPadding(dp(2), 0, dp(2), 0) } }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        chips.forEachIndexed { i, btn ->
            val r = if (i < 2) row else row2
            r.addView(btn, LinearLayout.LayoutParams(0, dp(48), 1f).apply { if (i % 2 > 0) leftMargin = dp(6) })
            btn.setOnClickListener { selectMode(i) }
        }
        row2.addView(View(this), LinearLayout.LayoutParams(0, dp(48), 1f).apply { leftMargin = dp(6) })
        c2.addView(row, lp(10))
        c2.addView(row2, lp(8))

        val c3 = card(pageSketch, "Atur hasil")
        val arow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        autoBtns = listOf(button("Auto", Color.WHITE), button("Manual", Color.WHITE))
        autoBtns.forEachIndexed { i, btn ->
            arow.addView(btn, LinearLayout.LayoutParams(0, dp(44), 1f).apply { if (i > 0) leftMargin = dp(6) })
            btn.setOnClickListener { selectAuto(i == 0) }
        }
        c3.addView(arow, lp(10))
        c3.addView(TextView(this).apply {
            text = "Auto: nilai terbaik dipilih otomatis sesuai gaya (Arsir: ketebalan 30%, kegelapan 35%)"
            textSize = 12f; setTextColor(cMuted); setPadding(dp(2), dp(8), 0, 0)
        })
        skBlur = seekRow(c3, { "Ketebalan / kehalusan garis: $it%" }, 100, 40, true).second
        skDark = seekRow(c3, { "Kegelapan: $it%" }, 100, 70, true).second
        val cr = seekRow(c3, { "Kekuatan warna: $it%" }, 100, 75, true)
        colorBox = cr.first; skColor = cr.second
        skGrain = seekRow(c3, { "Tekstur kertas: $it%" }, 100, 55, true).second
        skPaper = spinner(c3, "Latar kertas", listOf("Kertas putih", "Kertas krem", "Papan tulis (kapur)", "Transparan (PNG, hanya garis)"))
        skPaper.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { schedule() }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        val act = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(16), dp(14), 0) }
        skSave = button("Simpan Sketsa ke Galeri", cYellow).apply { textSize = 16f; alpha = 0.5f; isEnabled = false }
        skShare = button("Bagikan Sketsa", Color.WHITE).apply { alpha = 0.5f; isEnabled = false }
        skToCut = button("\u2702\uFE0F Lanjut: Hapus Latar", Color.WHITE).apply { alpha = 0.5f; isEnabled = false }
        skToVideo = button("\uD83C\uDFAC Langsung ke SpeedPaint", Color.WHITE).apply { alpha = 0.5f; isEnabled = false }
        skStatus = TextView(this).apply { gravity = Gravity.CENTER; setTextColor(cInk); textSize = 14f }
        act.addView(skSave, lp(0, dp(54)))
        act.addView(skShare, lp(8, dp(48)))
        act.addView(skToCut, lp(8, dp(48)))
        act.addView(skToVideo, lp(8, dp(48)))
        act.addView(skStatus, lp(10))
        pageSketch.addView(act)
        skSave.setOnClickListener { saveSketch(false) }
        skShare.setOnClickListener { if (savedUri != null) shareImage(savedUri!!) else saveSketch(true) }
        skToCut.setOnClickListener { selectTab(1) }
        skToVideo.setOnClickListener { spSrc.setSelection(1); selectTab(2) }
    }

    private fun selectAuto(a: Boolean) {
        val sbs = listOf(skBlur, skDark, skColor, skGrain)
        if (a && !autoMode) sbs.forEachIndexed { i, s -> manualVals[i] = s.progress }
        autoMode = a
        val v = if (a) (if (mode == 5) intArrayOf(30, 35, 60, 45) else if (mode >= 3) intArrayOf(30, 35, 75, 45) else intArrayOf(40, 70, 75, 55)) else manualVals
        sbs.forEachIndexed { i, s -> s.progress = v[i]; s.isEnabled = !a; s.alpha = if (a) 0.45f else 1f }
        autoBtns.forEachIndexed { k, btn -> btn.background = rounded(if ((k == 0) == a) cYellow else Color.WHITE, 14, cInk) }
        schedule()
    }

    /** Nomor gaya di Sketcher untuk tiap tombol: Arsir, Arsir + AI, Arsir Berwarna + AI. */
    private val modeIds = intArrayOf(3, 4, 5)

    private fun selectMode(i: Int) {
        mode = modeIds[i]
        chips.forEachIndexed { k, btn -> btn.background = rounded(if (k == i) cYellow else Color.WHITE, 14, cInk) }
        colorBox.visibility = if (mode == 1 || mode == 5) View.VISIBLE else View.GONE
        if (mode >= 4) {
            if (AiPortrait.available()) Toast.makeText(this, "Pertama kali: model AI disiapkan dulu, tunggu beberapa detik", Toast.LENGTH_LONG).show()
            else Toast.makeText(this, "Model AI tidak ada di APK ini (build lewat GitHub dengan langkah unduh model)", Toast.LENGTH_LONG).show()
        }
        if (autoMode) selectAuto(true) else schedule()
    }

    private fun sketchParams() = SketchParams(mode, skBlur.progress, skDark.progress, skColor.progress, skGrain.progress, skPaper.selectedItemPosition)

    private fun schedule() {
        handler.removeCallbacks(job)
        handler.postDelayed(job, 150)
    }

    private fun updatePreview() {
        val show = when (tab) {
            0 -> result ?: base
            1 -> cutShow ?: result ?: base
            else -> when (spSrc.selectedItemPosition) {
                0 -> base
                1 -> result ?: base
                else -> cutShow ?: result ?: base
            }
        }
        if (show != null) preview.setImageBitmap(show)
    }

    private fun renderPreview() {
        val bm = base ?: return
        val p = sketchParams()
        val g = ++gen
        Thread {
            try {
                val r = Sketcher.renderHD(bm, p)
                runOnUiThread { if (g == gen) { result = r; savedUri = null; updatePreview(); if (cutMask != null) applyCut() } }
            } catch (e: Throwable) {
                runOnUiThread { skStatus.text = "Gagal: ${e.message}" }
            }
        }.start()
    }

    private fun saveSketch(thenShare: Boolean) {
        val u = srcUri ?: return
        val p = sketchParams()
        skStatus.text = "Menyimpan..."
        Thread {
            try {
                val out = Sketcher.renderHD(decode(u, 2048), p)
                val png = p.paper == 3
                val cv = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, "sketsa_${System.currentTimeMillis()}." + (if (png) "png" else "jpg"))
                    put(MediaStore.Images.Media.MIME_TYPE, if (png) "image/png" else "image/jpeg")
                    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/JPG to Sketsa")
                }
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)!!
                contentResolver.openOutputStream(uri)!!.use { out.compress(if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, 95, it) }
                savedUri = uri
                savedPng = png
                runOnUiThread {
                    skStatus.text = "Tersimpan di Pictures/JPG to Sketsa"
                    if (thenShare) shareImage(uri)
                }
            } catch (e: Throwable) {
                runOnUiThread { skStatus.text = "Gagal menyimpan: ${e.message}" }
            }
        }.start()
    }

    private fun shareImage(uri: Uri, png: Boolean = savedPng) {
        val i = Intent(Intent.ACTION_SEND).setType(if (png) "image/png" else "image/jpeg").putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(i, "Bagikan sketsa"))
    }

    // ---------------- Tab Hapus Latar ----------------
    private fun buildCutPage() {
        val c1 = card(pageCut, "Hapus latar belakang")
        c1.addView(TextView(this).apply {
            text = "Latar dihapus dari hasil sketsa (langkah 1). Objek dikenali otomatis dari foto, hasilnya PNG transparan. Pilih \"Transparan\" pada Latar kertas di langkah 1 jika ingin garis saja."
            textSize = 12f; setTextColor(cMuted); setPadding(dp(2), dp(8), 0, 0)
        })
        cutMethod = spinner(c1, "Metode deteksi", listOf("Objek (ML Kit)", "Warna latar (latar polos / langit)", "Gabungan (paling bersih)"), 2)
        cutMethod.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (base != null && tab == 1) { cutMask = null; cutResult = null; cutShow = null; runCut() }
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        cutInk = spinner(c1, "Warna objek", listOf("Warna asli", "Hitam (hanya garis, kertas transparan)", "Putih (hanya garis, kertas transparan)", "Hitam, isi objek opak (garis tidak hilang)"), 3)
        cutInk.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (cutMask != null && result != null) applyCut()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        cutRun = button("\u2702\uFE0F Deteksi Ulang Objek", cYellow).apply { alpha = 0.5f; isEnabled = false }
        c1.addView(cutRun, lp(10, dp(48)))
        cutRun.setOnClickListener { cutMask = null; cutResult = null; cutShow = null; runCut() }

        val c2 = card(pageCut, "Atur potongan")
        val delay: () -> Unit = { handler.removeCallbacks(cutJob); handler.postDelayed(cutJob, 120); Unit }
        cutThr = seekRow(c2, { "Ambang objek: $it% (naik = potongan lebih ketat)" }, 100, 50, false, delay).second
        cutSoft = seekRow(c2, { "Kehalusan tepi: $it%" }, 100, 30, false, delay).second

        val act = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(16), dp(14), 0) }
        cutSave = button("Simpan PNG Transparan ke Galeri", cYellow).apply { textSize = 16f; alpha = 0.5f; isEnabled = false }
        cutShare = button("Bagikan", Color.WHITE).apply { alpha = 0.5f; isEnabled = false }
        cutNext = button("\uD83C\uDFAC Lanjut ke SpeedPaint", Color.WHITE).apply { alpha = 0.5f; isEnabled = false }
        cutStatus = TextView(this).apply { gravity = Gravity.CENTER; setTextColor(cInk); textSize = 14f }
        act.addView(cutSave, lp(0, dp(54)))
        act.addView(cutShare, lp(8, dp(48)))
        act.addView(cutNext, lp(8, dp(48)))
        act.addView(cutStatus, lp(10))
        pageCut.addView(act)
        cutSave.setOnClickListener { saveCut(false) }
        cutShare.setOnClickListener { if (cutSavedUri != null) shareImage(cutSavedUri!!, true) else saveCut(true) }
        cutNext.setOnClickListener { spSrc.setSelection(2); selectTab(2) }
    }

    /** Deteksi objek pada foto pratinjau (sekali per foto), lalu terapkan ke hasil sketsa. */
    private fun runCut() {
        val bm = base ?: return
        if (cutBusy) return
        cutBusy = true
        val g = photoGen
        val meth = cutMethod.selectedItemPosition
        cutStatus.text = "Mendeteksi objek... (pertama kali bisa lebih lama karena model diunduh)"
        Thread {
            try {
                val m = BackgroundRemover.detect(bm, meth)
                runOnUiThread {
                    cutBusy = false
                    if (g == photoGen) {
                        cutMask = m
                        cutStatus.text = if (m.fallback) "Memakai deteksi warna latar (cocok untuk latar polos)" else "Objek terdeteksi"
                        applyCut()
                    } else if (tab == 1) runCut()
                }
            } catch (e: Throwable) {
                runOnUiThread { cutBusy = false; cutStatus.text = "Gagal: ${e.message}" }
            }
        }.start()
    }

    private fun applyCut() {
        val r = result ?: return
        val m = cutMask ?: return
        val thr = cutThr.progress
        val soft = cutSoft.progress
        val ink = cutInk.selectedItemPosition
        val paper = skPaper.selectedItemPosition
        val g = ++cutGen
        Thread {
            try {
                val out = BackgroundRemover.recolor(BackgroundRemover.apply(r, m, thr, soft), ink, paper)
                val shown = BackgroundRemover.onChecker(out, ink == 2)
                runOnUiThread { if (g == cutGen) { cutResult = out; cutShow = shown; cutSavedUri = null; updatePreview() } }
            } catch (e: Throwable) {
                runOnUiThread { cutStatus.text = "Gagal: ${e.message}" }
            }
        }.start()
    }

    private fun saveCut(thenShare: Boolean) {
        val u = srcUri ?: return
        val p = sketchParams()
        val thr = cutThr.progress
        val soft = cutSoft.progress
        val meth = cutMethod.selectedItemPosition
        val ink = cutInk.selectedItemPosition
        cutStatus.text = "Memproses & menyimpan..."
        Thread {
            try {
                val big = decode(u, 2048)
                val sk = Sketcher.render(big, p)
                val m = BackgroundRemover.detect(big, meth)
                val out = BackgroundRemover.cropToContent(BackgroundRemover.recolor(BackgroundRemover.apply(sk, m, thr, soft), ink, p.paper))
                val cv = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, "sketsa_tanpa_latar_${System.currentTimeMillis()}.png")
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/JPG to Sketsa")
                }
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)!!
                contentResolver.openOutputStream(uri)!!.use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
                cutSavedUri = uri
                runOnUiThread {
                    cutStatus.text = "Tersimpan (PNG transparan) di Pictures/JPG to Sketsa"
                    if (thenShare) shareImage(uri, true)
                }
            } catch (e: Throwable) {
                runOnUiThread { cutStatus.text = "Gagal menyimpan: ${e.message}" }
            }
        }.start()
    }

    // ---------------- Tab SpeedPaint ----------------
    private fun buildPaintPage() {
        val cs = card(pagePaint, "Sumber gambar")
        spSrc = spinner(cs, "Gambar yang dipakai", listOf("Foto asli", "Hasil sketsa (langkah 1)", "Sketsa tanpa latar (langkah 2)"))
        spSrc.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { updatePreview() }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        val c2 = card(pagePaint, "Gaya menggambar")
        spStyle = spinner(c2, "Gaya", listOf("Ikuti garis, lalu warna", "Langsung warna (menyapu)", "Ikuti garis saja", "Langsung warna, ikuti garis"))
        spDir = spinner(c2, "Arah", listOf("Kiri ke kanan", "Atas ke bawah", "Dari tengah keluar", "Acak alami (per bagian, beda tiap video)"), 3)
        spPaper = spinner(c2, "Latar kertas", listOf("Putih", "Krem", "Papan tulis", "Kertas buku bergaris"))
        spInk = spinner(c2, "Warna goresan sketsa", listOf("Otomatis (hitam / putih)", "Biru tua (pulpen)", "Cokelat sepia", "Abu-abu pensil", "Warna asli foto"))

        val c3 = card(pagePaint, "Video")
        seekDur = seekRow(c3, { "Durasi: ${it + 5} detik" }, 55, 10).second
        spRatio = spinner(c3, "Rasio video", listOf("Sesuai foto", "9:16 (Reels/TikTok)", "1:1 (Instagram)", "16:9 (YouTube)"))
        spRes = spinner(c3, "Resolusi", listOf("720p", "1080p"))
        spFps = spinner(c3, "FPS video", listOf("24 fps", "30 fps", "60 fps"), 1)
        spHold = spinner(c3, "Tahan hasil akhir", listOf("0 detik", "1 detik", "2 detik", "3 detik"), 1)

        val c4 = card(pagePaint, "Deteksi garis")
        spSource = spinner(c4, "Sumber garis", listOf("Otomatis (hitam-putih / foto)", "Tepi saja (untuk foto)", "Area gelap (gambar hitam-putih)"))
        spSens = spinner(c4, "Kepekaan garis", listOf("Otomatis (sesuai gambar)", "Lebih sedikit garis", "Lebih banyak garis"))
        spThick = spinner(c4, "Ketebalan garis", listOf("Otomatis (sesuai gambar)", "Tipis", "Sedang", "Tebal"))

        val c5 = card(pagePaint, "Tangan")
        handCheck = CheckBox(this).apply {
            text = "Tampilkan gambar tangan"; isChecked = true; setTextColor(cInk)
            buttonTintList = ColorStateList.valueOf(cInk)
        }
        c5.addView(handCheck, lp(6))
        seekHand = seekRow(c5, { "Ukuran tangan: ${it + 20}%" }, 80, 35).second
        seekSpeed = seekRow(c5, { "Kecepatan gerak tangan: x${(it + 5) / 10f}" }, 25, 5).second
        handInfo = TextView(this).apply { textSize = 12f; setTextColor(cMuted); setPadding(dp(2), dp(10), 0, 0) }
        c5.addView(handInfo)
        val hb = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val loadHandBtn = button("Ganti tangan (PNG)", Color.WHITE)
        val resetHandBtn = button("Bawaan", Color.WHITE)
        hb.addView(loadHandBtn, LinearLayout.LayoutParams(0, dp(46), 2f).apply { rightMargin = dp(8) })
        hb.addView(resetHandBtn, LinearLayout.LayoutParams(0, dp(46), 1f))
        c5.addView(hb, lp(10))
        handCheck.setOnCheckedChangeListener { _, on ->
            seekHand.isEnabled = on; seekSpeed.isEnabled = on
            loadHandBtn.isEnabled = on; resetHandBtn.isEnabled = on
            loadHandBtn.alpha = if (on) 1f else 0.4f; resetHandBtn.alpha = if (on) 1f else 0.4f
        }
        loadHandBtn.setOnClickListener { startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }, 2) }
        resetHandBtn.setOnClickListener { File(filesDir, "hand_custom.png").delete(); refreshHandInfo() }

        val act = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(16), dp(14), 0) }
        generate = button("\u25B6  Buat Video Speedpaint", cYellow).apply { textSize = 16f; alpha = 0.5f; isEnabled = false }
        cancel = button("Batalkan", Color.WHITE, cDanger).apply { visibility = View.GONE }
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            visibility = View.GONE; progressTintList = ColorStateList.valueOf(cInk)
        }
        pStatus = TextView(this).apply { gravity = Gravity.CENTER; setTextColor(cInk); textSize = 14f }
        watch = button("Putar Video", cYellow).apply { visibility = View.GONE }
        shareVideo = button("Bagikan Video", Color.WHITE).apply { visibility = View.GONE }
        act.addView(generate, lp(0, dp(56)))
        act.addView(cancel, lp(8, dp(48)))
        act.addView(bar, lp(12))
        act.addView(pStatus, lp(8))
        act.addView(watch, lp(10, dp(50)))
        act.addView(shareVideo, lp(8, dp(50)))
        pagePaint.addView(act)
        generate.setOnClickListener { startRender() }
        cancel.setOnClickListener { cancelFlag = true; pStatus.text = "Membatalkan..." }
        watch.setOnClickListener {
            videoUri?.let {
                startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(it, "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
            }
        }
        shareVideo.setOnClickListener {
            videoUri?.let {
                val i = Intent(Intent.ACTION_SEND).setType("video/mp4").putExtra(Intent.EXTRA_STREAM, it)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                startActivity(Intent.createChooser(i, "Bagikan video"))
            }
        }
    }

    private fun refreshHandInfo() {
        handInfo.text = if (File(filesDir, "hand_custom.png").exists()) "Tangan: gambar pilihan Anda" else "Tangan: bawaan"
    }

    private fun loadHand(): Bitmap? {
        if (!handCheck.isChecked) return null
        val f = File(filesDir, "hand_custom.png")
        if (f.exists()) {
            val bo = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.path, bo)
            val ss = max(1, bo.outWidth / 1600)
            return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = ss })
        }
        val id = resources.getIdentifier("hand", "drawable", packageName)
        return if (id != 0) BitmapFactory.decodeResource(resources, id) else null
    }

    private fun startRender() {
        val u = srcUri ?: return
        val secs = seekDur.progress + 5
        val srcMode = spSrc.selectedItemPosition
        val fromSketch = srcMode >= 1
        val cThr = cutThr.progress
        val cSoft = cutSoft.progress
        val cMeth = cutMethod.selectedItemPosition
        val cInk = cutInk.selectedItemPosition
        val opts = PaintOptions(
            style = spStyle.selectedItemPosition,
            direction = spDir.selectedItemPosition,
            paper = spPaper.selectedItemPosition,
            ratio = spRatio.selectedItemPosition,
            res = if (spRes.selectedItemPosition == 1) 1080 else 720,
            handPct = seekHand.progress + 20,
            handSpeed = (seekSpeed.progress + 5) / 10f,
            holdSec = spHold.selectedItemPosition,
            fps = intArrayOf(24, 30, 60)[spFps.selectedItemPosition],
            sens = spSens.selectedItemPosition,
            thick = spThick.selectedItemPosition,
            source = spSource.selectedItemPosition,
            ink = spInk.selectedItemPosition,
            transparentSrc = fromSketch
        )
        val sp = sketchParams()
        val hand = loadHand()
        cancelFlag = false
        generate.isEnabled = false; generate.alpha = 0.5f
        cancel.visibility = View.VISIBLE
        watch.visibility = View.GONE; shareVideo.visibility = View.GONE
        bar.progress = 0; bar.visibility = View.VISIBLE
        pStatus.text = "Membuat video..."
        Thread {
            try {
                var bmp = decode(u, 1600)
                if (fromSketch) {
                    val orig = bmp
                    bmp = Sketcher.render(orig, SketchParams(sp.mode, sp.blur, sp.dark, sp.color, sp.grain, 3))
                    if (srcMode == 2) {
                        runOnUiThread { pStatus.text = "Menghapus latar..." }
                        val m = BackgroundRemover.detect(orig, cMeth)
                        bmp = BackgroundRemover.cropToContent(BackgroundRemover.recolor(BackgroundRemover.apply(bmp, m, cThr, cSoft), cInk, 3))
                        runOnUiThread { pStatus.text = "Membuat video..." }
                    }
                }
                val tmp = File(cacheDir, "speedpaint.mp4")
                SpeedPaint.render(bmp, secs, tmp, opts, hand, { cancelFlag }) { p -> runOnUiThread { bar.progress = p } }
                if (cancelFlag) {
                    tmp.delete()
                    runOnUiThread { pStatus.text = "Dibatalkan" }
                } else {
                    val cv = ContentValues().apply {
                        put(MediaStore.Video.Media.DISPLAY_NAME, "speedpaint_${System.currentTimeMillis()}.mp4")
                        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                        put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/SpeedPaint")
                    }
                    val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)!!
                    contentResolver.openOutputStream(uri)!!.use { o -> tmp.inputStream().use { it.copyTo(o) } }
                    videoUri = uri
                    runOnUiThread {
                        pStatus.text = "Selesai! Tersimpan di Movies/SpeedPaint"
                        watch.visibility = View.VISIBLE; shareVideo.visibility = View.VISIBLE
                    }
                }
            } catch (e: Throwable) {
                runOnUiThread { pStatus.text = "Gagal: ${e.message}" }
            } finally {
                runOnUiThread { generate.isEnabled = true; generate.alpha = 1f; cancel.visibility = View.GONE; bar.visibility = View.GONE }
            }
        }.start()
    }

    // ---------------- Umum ----------------
    private fun selectTab(i: Int) {
        tab = i
        tabBtns.forEachIndexed { k, t -> t.background = rounded(if (k == i) cYellow else Color.WHITE, 14, cInk) }
        pageSketch.visibility = if (i == 0) View.VISIBLE else View.GONE
        pageCut.visibility = if (i == 1) View.VISIBLE else View.GONE
        pagePaint.visibility = if (i == 2) View.VISIBLE else View.GONE
        updatePreview()
        if (i == 1 && base != null && cutMask == null) runCut()
    }

    private fun decode(uri: Uri, maxSide: Int): Bitmap =
        ImageDecoder.decodeBitmap(ImageDecoder.createSource(contentResolver, uri)) { dec, info, _ ->
            dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val m = max(info.size.width, info.size.height)
            if (m > maxSide) {
                val s = maxSide.toFloat() / m
                dec.setTargetSize((info.size.width * s).toInt().coerceAtLeast(1), (info.size.height * s).toInt().coerceAtLeast(1))
            }
        }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data ?: return
        if (res != RESULT_OK) return
        if (req == 1) {
            try {
                srcUri = uri
                base = decode(uri, 900)
                result = null
                photoGen++; cutGen++
                cutMask = null; cutResult = null; cutShow = null; cutSavedUri = null
                hint.visibility = View.GONE
                savedUri = null
                skStatus.text = ""; pStatus.text = ""; cutStatus.text = ""
                for (b in listOf(skSave, skShare, skToCut, skToVideo, cutRun, cutSave, cutShare, cutNext, generate)) { b.isEnabled = true; b.alpha = 1f }
                updatePreview()
                schedule()
                if (tab == 1) runCut()
            } catch (e: Throwable) {
                skStatus.text = "Gagal membuka foto: ${e.message}"
            }
        } else if (req == 2) {
            val f = File(filesDir, "hand_custom.png")
            try {
                contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                val bo = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(f.path, bo)
                if (bo.outWidth <= 0) { f.delete(); Toast.makeText(this, "File bukan gambar", Toast.LENGTH_SHORT).show() }
            } catch (e: Exception) {
                f.delete(); Toast.makeText(this, "Gagal: ${e.message}", Toast.LENGTH_SHORT).show()
            }
            refreshHandInfo()
        }
    }
}
